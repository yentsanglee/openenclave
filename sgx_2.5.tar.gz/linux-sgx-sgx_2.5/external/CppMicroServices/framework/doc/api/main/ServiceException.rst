ServiceException
----------------

.. doxygengroup:: gr_serviceexception
   :content-only:
