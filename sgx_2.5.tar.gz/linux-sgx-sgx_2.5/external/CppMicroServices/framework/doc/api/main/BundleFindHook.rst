BundleFindHook
--------------

.. doxygenstruct:: cppmicroservices::BundleFindHook
