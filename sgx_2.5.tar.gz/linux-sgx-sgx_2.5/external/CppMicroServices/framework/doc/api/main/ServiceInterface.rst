ServiceInterface
----------------

.. doxygengroup:: gr_serviceinterface
   :content-only:

.. doxygendefine:: CPPMICROSERVICES_DECLARE_SERVICE_INTERFACE
   :no-link:
