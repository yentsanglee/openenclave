ServiceListenerHook
-------------------

.. doxygengroup:: gr_servicelistenerhook
   :content-only:
