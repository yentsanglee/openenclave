BundleResourceStream
--------------------

.. doxygenclass:: cppmicroservices::BundleResourceStream
