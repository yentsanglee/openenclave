ServiceFactory
--------------

.. doxygenclass:: cppmicroservices::ServiceFactory
