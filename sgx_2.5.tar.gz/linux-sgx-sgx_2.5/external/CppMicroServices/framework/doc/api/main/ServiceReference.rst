ServiceReference
----------------

.. doxygengroup:: gr_servicereference
   :content-only:
