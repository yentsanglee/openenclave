BundleResource
--------------

.. doxygengroup:: gr_bundleresource
   :content-only:
