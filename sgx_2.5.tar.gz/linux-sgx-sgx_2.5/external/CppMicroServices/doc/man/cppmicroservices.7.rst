.. This is the contents of the general man page section (7).

.. _`cppmicroservices(7)`:

Framework
=========

.. toctree::

   /framework/doc/resources
   /framework/doc/bundle_properties
   /framework/doc/service_hooks
   /framework/doc/static_bundles
   