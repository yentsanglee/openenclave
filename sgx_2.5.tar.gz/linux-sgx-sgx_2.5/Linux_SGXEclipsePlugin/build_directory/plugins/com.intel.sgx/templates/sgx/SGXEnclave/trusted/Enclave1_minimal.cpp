#include "$(enclaveName)_t.h"  /* print_string */

int ecall_$(enclaveName)_sample()
{
  return 0;
}

